'use client';

/**
 * ═══════════════════════════════════════════════════════════
 * PADQ — Spectator / Watch Page
 * Route: /watch/[sessionId]
 * ═══════════════════════════════════════════════════════════
 *
 * READ-ONLY. Zero write access to Firebase.
 *
 * Guardrails:
 *  1. Validates the sessionId exists before rendering anything
 *  2. Redirects to home if invalid
 *  3. Subscribes ONLY to the session the host created
 *  4. Viewer can ONLY see the mode/view the host is currently on
 *     (no tab-switching, no bracket reseed, no scoring)
 *  5. All interactive elements are hidden or disabled
 *  6. hostToken is never exposed — viewers only read public fields
 * ═══════════════════════════════════════════════════════════
 */

import React, { useState, useEffect, useRef, useMemo, Suspense } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  Trophy, Flame, History, ArrowLeft, Users, Swords,
  Wifi, WifiOff, Check,
  BarChart2, TrendingUp, Activity, Clock, AlertCircle,
  Loader2,
} from 'lucide-react';
import {
  subscribeToSession,
  subscribeToHistory,
  loadSession,
  SessionDoc,
  MatchHistoryEntry,
  TournamentMatch,
} from '@/lib/sessionService';
import { useSessionAccess } from '@/hooks/useSessionAccess';
import AccessCodeModal from '@/app/queue/components/atoms/AccessCodeModal';
import { RankBadge } from '@/app/queue/components/atoms/RankBadge';
import { StreakBadge } from '@/app/queue/components/atoms/StreakBadge';
import type { RankTier, PlayerStat } from '@/app/queue/lib/types';
import { buildPlayerStats } from '@/app/queue/lib/playerUtils';
import './watch.css';

// ═══════════════════════════════════════════════════════════
// SMALL UI ATOMS
// ═══════════════════════════════════════════════════════════

const StatBar: React.FC<{ value: number; max: number; color: string }> = ({ value, max, color }) => (
  <div className="w-bar-track"><div className="w-bar-fill" style={{ width: `${max === 0 ? 0 : Math.round((value / max) * 100)}%`, background: color }} /></div>
);

// ═══════════════════════════════════════════════════════════
// BRACKET DISPLAY (read-only)
// ═══════════════════════════════════════════════════════════

const BracketSection: React.FC<{
  title: string;
  matches: TournamentMatch[];
  totalRounds: number;
  bracketType: 'W' | 'L' | 'GF';
}> = ({ title, matches, totalRounds, bracketType }) => {
  const byRound: Record<number, TournamentMatch[]> = {};
  matches.forEach(m => { (byRound[m.round] ??= []).push(m); });
  const rounds = Object.keys(byRound).map(Number).sort((a, b) => a - b);

  const label = (r: number) => {
    if (bracketType === 'GF') return 'Grand Final';
    if (bracketType === 'W') {
      const rem = totalRounds - r;
      if (rem === 1) return 'Final'; if (rem === 2) return 'Semis'; if (rem === 3) return 'Quarters';
      return `WB Round ${r + 1}`;
    }
    if (bracketType === 'L') {
      if (r === Math.max(...rounds)) return 'LB Final';
      return r % 2 === 0 ? `LB Round ${Math.floor(r / 2) + 1}` : `LB Elim ${Math.floor(r / 2) + 1}`;
    }
    return `Round ${r + 1}`;
  };

  return (
    <div className="w-bracket-section">
      {title && <div className="w-bracket-section-title">{title}</div>}
      <div className="w-bracket-container">
        {rounds.map(r => (
          <div key={r} className="w-bracket-round">
            <div className="w-bracket-round-label">{label(r)}</div>
            <div className="w-bracket-round-matches">
              {byRound[r].sort((a, b) => a.slot - b.slot).map(m => {
                const p1Won = m.winner === m.player1, p2Won = m.winner === m.player2;
                return (
                  <div key={m.id} className={['w-bracket-match', m.winner ? 'done' : '', m.isBye ? 'bye' : '', bracketType === 'L' ? 'losers' : '', bracketType === 'GF' ? 'gf' : ''].filter(Boolean).join(' ')}>
                    <div className={['w-bracket-player', p1Won ? 'winner' : m.winner ? 'loser' : ''].filter(Boolean).join(' ')}>
                      <span>{m.player1 ?? <span className="tbd">TBD</span>}</span>
                      {p1Won && <Check size={11} />}
                    </div>
                    <div className="w-bracket-divider" />
                    <div className={['w-bracket-player', p2Won ? 'winner' : m.winner ? 'loser' : ''].filter(Boolean).join(' ')}>
                      <span>{m.isBye ? <span className="bye-label">No Player</span> : m.player2 ?? <span className="tbd">TBD</span>}</span>
                      {p2Won && <Check size={11} />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════
// MAIN SPECTATOR PAGE
// ═══════════════════════════════════════════════════════════

function WatchPageContent() {
  const params    = useParams();
  const router    = useRouter();
  const sessionId = (params?.sessionId as string ?? '').toUpperCase();

  // ── Access control: PIN gate ─────────────────────────────
  const { access, submitPin } = useSessionAccess(sessionId);

  // ── Firebase state ──────────────────────────────────────
  const [session,         setSession]         = useState<SessionDoc | null>(null);
  const [history,         setHistory]         = useState<MatchHistoryEntry[]>([]);
  const [status,          setStatus]          = useState<'loading' | 'live' | 'reconnecting' | 'error' | 'ended' | 'expired'>('loading');
  const [errorMsg,        setErrorMsg]        = useState('');
  const [showHistory,     setShowHistory]     = useState(true);
  const [showAllHistory,  setShowAllHistory]  = useState(false);

  // ── Match announcement (Task 12) ────────────────────────
  const [announcement,   setAnnouncement]    = useState<string | null>(null);
  const prevMatchKeyRef = useRef<string>('');

  // ── Guardrail: validate session exists before subscribing ──

  useEffect(() => {
    if (!sessionId || sessionId.length < 4) {
      setStatus('error');
      setErrorMsg('Invalid room code.');
      return;
    }

    let unsubSession: (() => void) | null  = null;
    let unsubHistory: (() => void) | null  = null;

    // First do a one-time read to confirm existence
    loadSession(sessionId).then(data => {
      if (!data) {
        setStatus('error');
        setErrorMsg(`Session "${sessionId}" not found. It may have expired or the code is wrong.`);
        return;
      }

      // Session exists — set initial state then subscribe
      setSession(data);
      setStatus('live');

      // Real-time listener — handles updates, deletion, and errors
      unsubSession = subscribeToSession(
        sessionId,
        // onChange: normal update
        (updated) => {
          setSession(updated);
          setStatus('live');
        },
        // onError: connection dropped — show reconnecting state
        (err) => {
          console.error('[Watch] snapshot error', err);
          setStatus('reconnecting');
        },
        // onDeleted: TTL fired or host hard-reset — session is gone
        () => {
          setStatus('expired');
          setSession(null);
        },
      );

      // Real-time listener for history subcollection.
      // OPTIMIZATION: Only subscribe when viewer opens the history panel.
      // Saves Firestore reads for viewers who only watch the queue/bracket.
      if (showHistory) {
        unsubHistory = subscribeToHistory(sessionId, (entries) => {
          setHistory(entries);
        });
      }
    });

    return () => {
      unsubSession?.();
      unsubHistory?.();
    };
  }, [sessionId]);

  // ── Match change detection — fires announcement ──────────
  useEffect(() => {
    if (!session?.isLive) return;
    const q  = session.queue ?? [];
    const gm = session.gameMode;
    let key = '';
    if (gm === 'singles' && q.length >= 2) key = `${q[0]}|${q[1]}`;
    else if (gm === 'doubles' && q.length >= 4) key = `${q[0]}|${q[1]}|${q[2]}|${q[3]}`;
    if (!key) return;

    if (prevMatchKeyRef.current && prevMatchKeyRef.current !== key) {
      const text = gm === 'singles'
        ? `${q[0]} vs ${q[1]}`
        : `${q[0]} & ${q[1]}  vs  ${q[2]} & ${q[3]}`;
      setAnnouncement(text);
      const timer = setTimeout(() => setAnnouncement(null), 6000);
      prevMatchKeyRef.current = key;
      return () => clearTimeout(timer);
    }
    prevMatchKeyRef.current = key;
  }, [session]);

  // ── Derived ─────────────────────────────────────────────

  const stats = useMemo(
    () => session ? buildPlayerStats(session.players, history) : [],
    [session, history],
  );
  const statsMap = useMemo(
    () => Object.fromEntries(stats.map(s => [s.name, s])),
    [stats],
  );

  // ── Error / loading screens ──────────────────────────────

  // ── PIN gate — must render before anything else ──────────
  if (access === 'checking') {
    return (
      <div className="watch-shell watch-shell--center">
        <Loader2 size={36} className="w-spin" />
        <p>Checking access…</p>
      </div>
    );
  }
  if (access === 'needs-pin') {
    return (
      <AccessCodeModal
        open={true}
        label="This session is PIN-protected"
        placeholder="Enter PIN"
        maxLength={4}
        onSubmit={async (pin) => {
          const ok = await submitPin(pin);
          if (!ok) throw new Error('Incorrect PIN. Please try again.');
        }}
        onClose={() => router.push('/')}
      />
    );
  }

  if (status === 'loading') {
    return (
      <div className="watch-shell watch-shell--center">
        <Loader2 size={36} className="w-spin" />
        <p>Connecting to session <strong>{sessionId}</strong>…</p>
      </div>
    );
  }

  // Reconnecting — connection dropped, Firestore retrying automatically
  if (status === 'reconnecting') {
    return (
      <div className="watch-shell watch-shell--center">
        <Loader2 size={36} className="w-spin" />
        <p style={{ color: '#f59e0b' }}>Reconnecting to session <strong>{sessionId}</strong>…</p>
        <p style={{ fontSize: '0.78rem', color: '#6b7280' }}>Please wait — this usually takes a few seconds.</p>
      </div>
    );
  }

  // Expired — TTL deleted the session, or host hard-reset
  if (status === 'expired') {
    return (
      <div className="watch-shell watch-shell--center">
        <AlertCircle size={40} className="w-error-icon" />
        <h2 className="w-error-title">Session Ended</h2>
        <p className="w-error-msg">
          This session has expired or been closed by the host.
          Sessions are automatically removed after 30 minutes of inactivity.
        </p>
        <button className="w-back-btn" onClick={() => router.push('/')}>
          <ArrowLeft size={14} /> Back to Home
        </button>
      </div>
    );
  }

  if (status === 'error' || status === 'ended') {
    return (
      <div className="watch-shell watch-shell--center">
        <AlertCircle size={40} className="w-error-icon" />
        <h2 className="w-error-title">{status === 'ended' ? 'Session Ended' : 'Session Not Found'}</h2>
        <p className="w-error-msg">{errorMsg || 'This session has ended or the room code is invalid.'}</p>
        <button className="w-back-btn" onClick={() => router.push('/')}>
          <ArrowLeft size={14} /> Back to Home
        </button>
      </div>
    );
  }

  if (!session) return null;

  // ── isLive guardrail ─────────────────────────────────────
  // If host hasn't clicked "Go Live", show a holding screen.
  // Real-time subscription is still active — page auto-updates
  // the moment the host goes live (session.isLive flips to true).
  if (!session.isLive) {
    return (
      <div className="watch-shell watch-shell--center">
        <div className="w-not-live-icon">📡</div>
        <h2 className="w-error-title" style={{ color: '#f0f4ff' }}>Session Not Live Yet</h2>
        <p className="w-error-msg">
          The host hasn't started broadcasting yet.<br />
          This page will update automatically when they go live.
        </p>
        <div className="w-not-live-room">
          <span className="w-not-live-label">Room</span>
          <span className="w-not-live-code">{sessionId}</span>
        </div>
        <div className="w-not-live-waiting">
          <Loader2 size={14} className="w-spin" style={{ color: '#6b7280' }} />
          <span>Waiting for host…</span>
        </div>
        <button className="w-back-btn" onClick={() => router.push('/')}>
          <ArrowLeft size={14} /> Back to Home
        </button>
      </div>
    );
  }

  // ── What the viewer sees — mirrors the HOST's current view ─
  const isTournament  = session.queueMode === 'tournament' && session.tournamentActive;
  const isSkilled     = session.queueMode === 'skilled';
  const isMultiCourt  = (session.courtSlots ?? []).length > 0;
  const queue         = session.queue ?? [];
  const gameMode      = session.gameMode;
  const courtSlots    = session.courtSlots ?? [];

  // Deserialize doubles engine state for winners/losers cycle display (Issue #2)
  let paddleStateForWatch: { phase: string; winnersPool: string[][]; losersPool: string[][]; playedThisCycle: Set<string> } | null = null;
  if (session.doublesEngineState) {
    try {
      const raw = session.doublesEngineState as Record<string, unknown>;
      paddleStateForWatch = {
        phase:           (raw.phase as string) ?? 'INIT',
        winnersPool:     ((raw.winnersPool as { a: string; b: string }[] | undefined) ?? []).map(p => [p.a, p.b]),
        losersPool:      ((raw.losersPool  as { a: string; b: string }[] | undefined) ?? []).map(p => [p.a, p.b]),
        playedThisCycle: new Set<string>((raw.playedThisCycle as string[] | undefined) ?? []),
      };
    } catch {
      paddleStateForWatch = null;
    }
  }

  // Current match detection (same logic as host)
  const pendingTournamentMatch = isTournament
    ? session.tournamentMatches?.find(m => !m.winner && !m.isBye && m.player1 && m.player2) ?? null
    : null;

  const currentSinglesMatch = !isTournament && gameMode === 'singles' && queue.length >= 2
    ? { p1: queue[0], p2: queue[1] }
    : null;

  const currentDoublesNext = !isTournament && gameMode === 'doubles' && queue.length >= 4
    ? queue.slice(0, 4)
    : null;

  // Upcoming pairs for the table — index 0 is "On Court", rest are "Upcoming Match N"
  const upcomingPairs: { label: string; left: string; right: string; isCurrent: boolean }[] = [];
  if (!isTournament) {
    const step = gameMode === 'doubles' ? 4 : 2;
    let matchNum = 1;
    for (let i = 0; i < Math.min(queue.length, step * 5); i += step) {
      const isCurrent = i === 0;
      const label = isCurrent ? '▶ On Court' : `Upcoming Match ${matchNum}`;
      if (gameMode === 'singles') {
        upcomingPairs.push({ label, left: queue[i] ?? '—', right: queue[i + 1] ?? 'Bye', isCurrent });
      } else {
        if (i + 3 < queue.length)
          upcomingPairs.push({ label, left: `${queue[i]} & ${queue[i + 1]}`, right: `${queue[i + 2]} & ${queue[i + 3]}`, isCurrent });
      }
      if (!isCurrent) matchNum++;
    }
  }

  return (
    <div className="watch-shell">
      {/* ── Match announcement overlay ── */}
      {announcement && (
        <div className="w-announcement" role="alert">
          <div className="w-announcement-inner">
            <div className="w-announcement-label">🏓 NEXT UP ON COURT</div>
            <div className="w-announcement-match">{announcement}</div>
            <button className="w-announcement-close" onClick={() => setAnnouncement(null)}>✕</button>
          </div>
        </div>
      )}

      {/* ── Top bar ── */}
      <div className="w-topbar">
        <button className="w-back-btn" onClick={() => router.push('/')}>
          <ArrowLeft size={14} /> Home
        </button>

        <div className="w-session-info">
          <span className={`w-dot ${status === 'live' ? 'w-dot--live' : 'w-dot--off'}`} />
          <span className="w-live-label">LIVE</span>
          <span className="w-room-code">{sessionId}</span>
        </div>

        <div className="w-topbar-mode">
          {gameMode === 'singles' ? <Swords size={14} /> : <Users size={14} />}
          {gameMode === 'singles' ? 'Singles' : 'Doubles'} ·{' '}
          {session.queueMode === 'tournament' ? 'Tournament' : session.queueMode === 'playall' ? 'Play-all' : 'Default'}
        </div>
      </div>

      {/* ── Viewer read-only banner ── */}
      <div className="w-viewer-banner">
        <Wifi size={13} /> You are watching live. Only the host can make changes.
      </div>

      <div className="w-body">

        {/* ══════════════════════════════════════════════════
            LIVE SCORE — shown at the TOP as the hero element
            when the host has scoring active
            ══════════════════════════════════════════════════ */}
        {session.liveScore?.active && (() => {
          const ls = session.liveScore!;
          const aWon = ls.scoreA >= ls.limit;
          const bWon = ls.scoreB >= ls.limit;
          return (
            <div className="w-live-score-hero">
              <div className="w-live-score-badge">
                <span className="w-live-dot" />
                LIVE SCORE
                {ls.deuce && <span className="w-deuce-pill">DEUCE</span>}
              </div>
              <div className="w-live-score-board">
                <div className={`w-live-side ${aWon ? 'w-live-side--winner' : ''}`}>
                  <div className="w-live-team-label">Team A</div>
                  <div className="w-live-player-name">{ls.labelA}</div>
                  <div className="w-live-score-num">{ls.scoreA}</div>
                </div>
                <div className="w-live-centre">
                  <div className="w-live-limit-badge">to {ls.limit}</div>
                  {(aWon || bWon) && <div className="w-live-gameover">Game Over!</div>}
                </div>
                <div className={`w-live-side ${bWon ? 'w-live-side--winner' : ''}`}>
                  <div className="w-live-team-label">Team B</div>
                  <div className="w-live-player-name">{ls.labelB}</div>
                  <div className="w-live-score-num">{ls.scoreB}</div>
                </div>
              </div>
            </div>
          );
        })()}
        {/* ══════════════════════════════════════════════════
            TOURNAMENT VIEW
            ══════════════════════════════════════════════════ */}
        {isTournament && (
          <div className="w-section">
            <h2 className="w-section-title">
              <Trophy size={17} /> Tournament Bracket
            </h2>

            {session.tournamentWinner && (
              <div className="w-champion">
                <Trophy size={20} /> Champion: {session.tournamentWinner}
              </div>
            )}

            {/* Bracket — same visual as host but no controls */}
            {session.elimType === 'single' ? (
              <BracketSection
                title=""
                matches={session.tournamentMatches ?? []}
                totalRounds={[...new Set((session.tournamentMatches ?? []).map(m => m.round))].length}
                bracketType="W"
              />
            ) : (
              <div className="w-bracket-de">
                {['W', 'L', 'GF'].map(bt => {
                  const filtered = (session.tournamentMatches ?? []).filter(m => m.bracket === bt);
                  if (!filtered.length) return null;
                  const wbRounds = [...new Set(filtered.filter(m => m.bracket === 'W').map(m => m.round))].length;
                  return (
                    <BracketSection
                      key={bt}
                      title={bt === 'W' ? 'Winners Bracket' : bt === 'L' ? 'Losers Bracket' : ''}
                      matches={filtered}
                      totalRounds={wbRounds}
                      bracketType={bt as 'W' | 'L' | 'GF'}
                    />
                  );
                })}
              </div>
            )}

            {/* Current tournament match */}
            {pendingTournamentMatch && !session.tournamentWinner && (
              <div className="w-current-match">
                <div className="w-current-match-label">
                  {pendingTournamentMatch.bracket === 'GF' && <Trophy size={14} />}
                  {pendingTournamentMatch.bracket === 'L' && '🔴 Losers — '}
                  {pendingTournamentMatch.bracket === 'GF' && ' Grand Final — '}
                  On Court Now
                </div>
                <div className="w-vs-row">
                  <span className="w-player-chip">
                    {pendingTournamentMatch.player1}
                    <StreakBadge streak={statsMap[pendingTournamentMatch.player1 ?? '']?.streak ?? 0} className="w-streak-badge" />
                  </span>
                  <span className="w-vs">VS</span>
                  <span className="w-player-chip">
                    {pendingTournamentMatch.player2}
                    <StreakBadge streak={statsMap[pendingTournamentMatch.player2 ?? '']?.streak ?? 0} className="w-streak-badge" />
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            SKILLED MODE VIEW
            ══════════════════════════════════════════════════ */}
        {!isTournament && isSkilled && (
          <div className="w-section">
            <h2 className="w-section-title"><Users size={16} /> Skilled Mode — Courts</h2>
            {courtSlots.length > 0 ? (
              <div className="w-courts-grid">
                {courtSlots.map(slot => {
                  const teamA = slot.onCourt.slice(0, 2);
                  const teamB = slot.onCourt.slice(2, 4);
                  const hasMatch = slot.onCourt.length >= 4;
                  return (
                    <div key={slot.id} className="w-court-card">
                      <div className="w-court-name">{slot.name}</div>
                      {hasMatch ? (
                        <div className="w-vs-row">
                          <span className="w-player-chip w-player-chip--team">{teamA.join(' & ')}</span>
                          <span className="w-vs">VS</span>
                          <span className="w-player-chip w-player-chip--team">{teamB.join(' & ')}</span>
                        </div>
                      ) : (
                        <p className="w-muted">Waiting for players…</p>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="w-muted">Courts not yet assigned.</p>
            )}
            {queue.length > 0 && (
              <div className="w-waiting-queue">
                <h3 className="w-subsection-title">Waiting Queue</h3>
                <div className="w-queue-chips">
                  {queue.map((p, i) => (
                    <span key={`wq-${i}-${p}`} className="w-queue-chip">
                      <span className="w-queue-num">#{i + 1}</span> {p}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            MULTI-COURT DOUBLES VIEW
            ══════════════════════════════════════════════════ */}
        {!isTournament && !isSkilled && isMultiCourt && gameMode === 'doubles' && (
          <div className="w-section">
            <h2 className="w-section-title"><Users size={16} /> Courts</h2>
            <div className="w-courts-grid">
              {courtSlots.map(slot => {
                const teamA = slot.onCourt.slice(0, 2);
                const teamB = slot.onCourt.slice(2, 4);
                const hasMatch = slot.onCourt.length >= 4;
                return (
                  <div key={slot.id} className="w-court-card">
                    <div className="w-court-name">{slot.name}</div>
                    {hasMatch ? (
                      <div className="w-vs-row">
                        <span className="w-player-chip w-player-chip--team">{teamA.join(' & ')}</span>
                        <span className="w-vs">VS</span>
                        <span className="w-player-chip w-player-chip--team">{teamB.join(' & ')}</span>
                      </div>
                    ) : (
                      <p className="w-muted">Waiting for players…</p>
                    )}
                  </div>
                );
              })}
            </div>
            {queue.length > 0 && (
              <div className="w-waiting-queue">
                <h3 className="w-subsection-title">Waiting Queue</h3>
                <div className="w-queue-chips">
                  {queue.map((p, i) => (
                    <span key={`wq-${i}-${p}`} className="w-queue-chip">
                      <span className="w-queue-num">#{i + 1}</span> {p}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            WINNERS / LOSERS CYCLE (Issue #2)
            Shows for any doubles non-tournament mode when
            paddleState has been synced from the host.
            ══════════════════════════════════════════════════ */}
        {!isTournament && gameMode === 'doubles' && paddleStateForWatch && paddleStateForWatch.phase !== 'INIT' && (
          <div className="w-section">
            <h2 className="w-section-title">
              {paddleStateForWatch.phase === 'WINNERS' ? '🏆 Winners Cycle' : '🔴 Losers Cycle'}
            </h2>
            <div className="w-cycle-pools">
              {paddleStateForWatch.winnersPool.length > 0 && (
                <div className="w-pool w-pool--winners">
                  <span className="w-pool-tag">W</span>
                  <div className="w-pool-pairs">
                    {paddleStateForWatch.winnersPool.map((pair, i) => (
                      <span key={`wp-${i}`} className={`w-pool-pair ${i === 0 ? 'w-pool-pair--active' : ''}`}>
                        {pair.join(' & ')}
                        {i === 0 && <span className="w-on-court-dot"> ▶</span>}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {paddleStateForWatch.losersPool.length > 0 && (
                <div className="w-pool w-pool--losers">
                  <span className="w-pool-tag">L</span>
                  <div className="w-pool-pairs">
                    {paddleStateForWatch.losersPool.map((pair, i) => (
                      <span key={`lp-${i}`} className={`w-pool-pair ${i === 0 ? 'w-pool-pair--active' : ''}`}>
                        {pair.join(' & ')}
                        {i === 0 && <span className="w-on-court-dot"> ▶</span>}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            QUEUE VIEW (default / play-all, single-court)
            ══════════════════════════════════════════════════ */}
        {!isTournament && !isSkilled && !isMultiCourt && (
          <>
            {/* Current match */}
            {currentSinglesMatch && (
              <div className="w-section">
                <h2 className="w-section-title"><Swords size={16} /> On Court Now</h2>
                <div className="w-vs-row">
                  <span className="w-player-chip">
                    {currentSinglesMatch.p1}
                    <StreakBadge streak={statsMap[currentSinglesMatch.p1]?.streak ?? 0} className="w-streak-badge" />
                  </span>
                  <span className="w-vs">VS</span>
                  <span className="w-player-chip">
                    {currentSinglesMatch.p2}
                    <StreakBadge streak={statsMap[currentSinglesMatch.p2]?.streak ?? 0} className="w-streak-badge" />
                  </span>
                </div>
              </div>
            )}

            {currentDoublesNext && (
              <div className="w-section">
                <h2 className="w-section-title"><Users size={16} /> On Court Now</h2>
                <div className="w-vs-row">
                  <span className="w-player-chip w-player-chip--team">
                    {currentDoublesNext[0]} & {currentDoublesNext[1]}
                  </span>
                  <span className="w-vs">VS</span>
                  <span className="w-player-chip w-player-chip--team">
                    {currentDoublesNext[2]} & {currentDoublesNext[3]}
                  </span>
                </div>
              </div>
            )}

            {/* Queue / upcoming matches */}
            {upcomingPairs.length > 0 && (
              <div className="w-section">
                <h2 className="w-section-title">
                  {gameMode === 'singles' ? <Swords size={15} /> : <Users size={15} />}
                  Upcoming Matches
                </h2>
                <table className="w-table">
                  <thead>
                    <tr>
                      <th>Match</th>
                      <th>{gameMode === 'singles' ? 'Player 1' : 'Team A'}</th>
                      <th>{gameMode === 'singles' ? 'Player 2' : 'Team B'}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {upcomingPairs.map((p, i) => (
                      <tr key={i} className={p.isCurrent ? 'w-next-row' : ''}>
                        <td className="w-match-label">{p.label}</td>
                        <td>{p.left}</td>
                        <td>{p.right}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}

        {/* ══════════════════════════════════════════════════
            STATS — always visible
            ══════════════════════════════════════════════════ */}
        {stats.length > 0 && (
          <div className="w-section">
            <h2 className="w-section-title"><BarChart2 size={15} /> Player Stats</h2>
            <div className="w-stats-table-wrap">
              <table className="w-stats-table">
                <thead>
                  <tr>
                    <th>#</th><th>Player</th><th>Rank</th>
                    <th><TrendingUp size={11} /> W</th><th>L</th>
                    <th><Activity size={11} /> GP</th><th>Win%</th><th>🔥</th>
                  </tr>
                </thead>
                <tbody>
                  {[...stats].sort((a, b) => b.wins - a.wins).map((s, i) => (
                    <tr key={s.name}>
                      <td className="w-col-num">{i + 1}</td>
                      <td><strong>{s.name}</strong></td>
                      <td><RankBadge rank={s.rank} className="w-rank-badge" /></td>
                      <td className="w-col-win">{s.wins}</td>
                      <td className="w-col-loss">{s.losses}</td>
                      <td>{s.gamesPlayed}</td>
                      <td>
                        <div className="w-wr-cell">
                          <span>{s.winRate}%</span>
                          <StatBar value={s.winRate} max={100} color="#22c55e" />
                        </div>
                      </td>
                      <td>{s.streak >= 2 ? <span className="w-streak-badge"><Flame size={11} />{s.streak}</span> : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════════════════
            MATCH HISTORY
            ══════════════════════════════════════════════════ */}
        <div className="w-section">
          <button
            className="w-history-toggle"
            onClick={() => setShowHistory(h => !h)}
          >
            <History size={14} /> {showHistory ? 'Hide' : 'Show'} Match History
            {history.length > 0 && <span className="w-history-count">{history.length}</span>}
          </button>

          {showHistory && (
            history.length === 0
              ? <p className="w-muted">No matches played yet.</p>
              : (
                <>
                  <ul className="w-history-list">
                    {(showAllHistory ? history : history.slice(0, 5)).map(e => (
                      <li key={e.id} className="w-history-item">
                        <span className="w-h-time">{e.timestamp}</span>
                        <span className="w-h-match">
                          {e.mode?.includes('(') && (
                            <span className="w-h-court">{e.mode.match(/\(([^)]+)\)/)?.[1]}</span>
                          )}
                          {e.players}
                        </span>
                        <span className="w-h-winner"><Trophy size={11} /> {e.winner}</span>
                        {e.score && <span className="w-h-score">{e.score}</span>}
                      </li>
                    ))}
                  </ul>
                  {history.length > 5 && (
                    <button className="w-show-all-btn" onClick={() => setShowAllHistory(a => !a)}>
                      {showAllHistory ? 'Show less' : `Show all ${history.length} results`}
                    </button>
                  )}
                </>
              )
          )}
        </div>
      </div>
    </div>
  );
}

export default function WatchPage() {
  return (
    <Suspense fallback={
      <div className="watch-shell watch-shell--center">
        <Loader2 size={32} className="w-spin" />
        <p>Loading…</p>
      </div>
    }>
      <WatchPageContent />
    </Suspense>
  );
}